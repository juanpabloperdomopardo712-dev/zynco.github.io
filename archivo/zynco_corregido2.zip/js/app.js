/*═══════════════════════════════════════════════════════════════════════════
                    ZYNCO — LÓGICA DE LA APLICACIÓN (UNIFICADA)
    Archivo único: fusiona app.js + pagos.js (sin duplicar lógica de
    reservas/pagos ni funciones repetidas).
═══════════════════════════════════════════════════════════════════════════*/

// Declarar la función globalmente para sincronizar los datos de la sesión actual
window.sincronizarDatosSesion = function() {
    fetch("php/sesion_actual.php")
        .then(res => res.json())
        .then(data => {
            console.log("Respuesta de sesión actual:", data);

            if (data.exito && data.usuario) {
                const u = data.usuario;

                // 1. Rellenar la tarjeta de perfil en la sección usuarios
                const lblNombre = document.getElementById("perfilNombreSession");
                const lblCorreo = document.getElementById("perfilCorreoSession");
                const lblRol = document.getElementById("perfilRolSession");

                if (lblNombre) lblNombre.textContent = u.nombre;
                if (lblCorreo) lblCorreo.textContent = u.email;
                if (lblRol) lblRol.textContent = u.rol;

                // 2. Sincronizar el cuadrito superior de la cabecera (rolHeader / .rol-usuario-dinamico)
                const elementosRol = document.querySelectorAll(".rol-usuario-dinamico");
                elementosRol.forEach(el => {
                    el.textContent = u.rol;
                });
            } else {
                console.warn("No se pudo obtener la sesión actual:", data.mensaje);
            }
        })
        .catch(err => console.error("Error al sincronizar la sesión:", err));
};

// Declarar la función globalmente para cambiar de sección
window.cambiarSeccion = function(idContenedor) {
    const dashboard = document.getElementById("dashboard");
    if (!dashboard) return;

    // Buscar todas las secciones con la clase .contenedor dentro del dashboard
    const secciones = dashboard.querySelectorAll(".contenedor");

    secciones.forEach(seccion => {
        if (seccion.id === idContenedor) {
            seccion.style.display = "block";
            seccion.classList.add("activo");

            // Si entramos a usuarios, sincronizamos sesión y cargamos la tabla
            if (idContenedor === "usuarios") {
                if (typeof window.sincronizarDatosSesion === "function") {
                    window.sincronizarDatosSesion();
                }
                if (typeof window.cargarUsuariosGlobal === "function") {
                    window.cargarUsuariosGlobal();
                }
            }

            if (idContenedor === "inicio" && typeof window.cargarInicioGlobal === "function") {
                window.cargarInicioGlobal();
            }
            if (idContenedor === "reportes" && typeof window.cargarReportesGlobal === "function") {
                window.cargarReportesGlobal();
            }
            if (idContenedor === "reservas" && typeof window.cargarReservasGlobal === "function") {
                window.cargarReservasGlobal();
            }
            if (idContenedor === "pagos" && typeof window.cargarPagosGlobal === "function") {
                window.cargarPagosGlobal();
            }
            if (idContenedor === "clientes" && typeof window.cargarClientesGlobal === "function") {
                window.cargarClientesGlobal();
            }
        } else {
            seccion.style.display = "none";
            seccion.classList.remove("activo");
        }
    });

    // Actualizar el título de la página en la cabecera
    const tituloPagina = document.getElementById("tituloPagina");
    if (tituloPagina) {
        const btnActivo = document.querySelector(`[data-contenedor="${idContenedor}"]`);
        if (btnActivo) {
            const span = btnActivo.querySelector("span");
            if (span) tituloPagina.textContent = span.textContent;
        }
    }

    // Actualizar clase activa en los botones del menú lateral
    const botonesMenu = document.querySelectorAll(".sidebar-menu button");
    botonesMenu.forEach(b => {
        if (b.getAttribute("data-contenedor") === idContenedor) {
            b.classList.add("activo");
        } else {
            b.classList.remove("activo");
        }
    });
};

document.addEventListener("DOMContentLoaded", () => {

    /*═══════════════════════════════════════════════════════════════════════
      1. REFERENCIAS A ELEMENTOS DEL DOM
    ═══════════════════════════════════════════════════════════════════════*/

    const login = document.getElementById("login");
    const dashboard = document.getElementById("dashboard");
    const loginForm = document.getElementById("loginForm");
    const inputUsuario = document.getElementById("usuario");
    const inputPassword = document.getElementById("password");
    const btnCerrarAdmin = document.getElementById("cerrarSesion");
    const tituloPagina = document.getElementById("tituloPagina");

    // Sección de Usuarios (CRUD)
    const formularioUsuario = document.querySelector("#usuarios .formulario-crud") || document.getElementById("formularioUsuario");
    const inputUsuarioIdEditar = document.getElementById("usuarioIdEditar");
    const inputUsuarioNombre = document.getElementById("usuarioNombre");
    const inputUsuarioCorreo = document.getElementById("usuarioCorreo");
    const inputUsuarioRol = document.getElementById("usuarioRol");
    const inputUsuarioPassword = document.getElementById("usuarioPassword");
    const btnGuardarUsuario = document.getElementById("btnGuardarUsuario");
    const btnCancelarEdicionUsuario = document.getElementById("btnCancelarEdicionUsuario");
    const tablaUsuarios = document.getElementById("tablaUsuarios");


    /*═══════════════════════════════════════════════════════════════════════
      2. UTILIDADES Y MENSAJES
    ═══════════════════════════════════════════════════════════════════════*/

    function mostrarSoloLogin() {
        if (login) login.style.display = "flex";
        if (dashboard) dashboard.style.display = "none";
    }

    function mostrarMensaje(idAviso, contenedorForm, mensaje, color) {
        if (!contenedorForm) return;
        let aviso = document.getElementById(idAviso);

        if (!aviso) {
            aviso = document.createElement("p");
            aviso.id = idAviso;
            aviso.style.marginTop = "10px";
            aviso.style.fontSize = "14px";
            contenedorForm.appendChild(aviso);
        }

        aviso.style.color = color || "#ff7c7c";
        aviso.textContent = mensaje;
    }

    function mostrarErrorLogin(mensaje) {
        mostrarMensaje("loginError", loginForm, mensaje, "#ff7c7c");
    }

    function limpiarErrorLogin() {
        const aviso = document.getElementById("loginError");
        if (aviso) aviso.remove();
    }

    function mostrarMensajeUsuarios(mensaje, color) {
        mostrarMensaje("usuariosMensaje", formularioUsuario, mensaje, color);
    }

    function limpiarMensajeUsuarios() {
        const aviso = document.getElementById("usuariosMensaje");
        if (aviso) aviso.remove();
    }


    /*═══════════════════════════════════════════════════════════════════════
      3. GESTIÓN DE USUARIOS (CRUD)
    ═══════════════════════════════════════════════════════════════════════*/

    function cargarUsuarios() {
        if (!tablaUsuarios) return;

        tablaUsuarios.innerHTML = '<tr><td colspan="4" style="text-align:center;">Cargando usuarios...</td></tr>';

        fetch("php/usuarios_listar.php")
            .then(respuesta => respuesta.json())
            .then(data => {
                if (!data.exito) {
                    tablaUsuarios.innerHTML = `<tr><td colspan="4" style="text-align:center;">${data.mensaje || "No se pudo cargar la lista."}</td></tr>`;
                    return;
                }

                if (!data.usuarios || data.usuarios.length === 0) {
                    tablaUsuarios.innerHTML = '<tr><td colspan="4" style="text-align:center;">No hay usuarios registrados.</td></tr>';
                    return;
                }

                tablaUsuarios.innerHTML = "";

                data.usuarios.forEach(u => {
                    const fila = document.createElement("tr");

                    fila.innerHTML = `
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>
                            <button class="btn-editar" title="Editar"><i class="fa-solid fa-pen"></i></button>
                            <button class="btn-eliminar" title="Eliminar"><i class="fa-solid fa-trash"></i></button>
                        </td>
                    `;

                    const celdas = fila.querySelectorAll("td");
                    celdas[0].textContent = u.nombre || "";
                    celdas[1].textContent = u.email || "";
                    celdas[2].textContent = u.rol || "";

                    fila.querySelector(".btn-editar").addEventListener("click", () => cargarUsuarioEnFormulario(u));
                    fila.querySelector(".btn-eliminar").addEventListener("click", () => eliminarUsuario(u.id, u.nombre));

                    tablaUsuarios.appendChild(fila);
                });
            })
            .catch(error => {
                console.error("Error al listar usuarios:", error);
                tablaUsuarios.innerHTML = '<tr><td colspan="4" style="text-align:center;">Error de conexión al cargar la tabla.</td></tr>';
            });
    }

    window.cargarUsuariosGlobal = cargarUsuarios;

    function cargarUsuarioEnFormulario(u) {
        if (inputUsuarioIdEditar) inputUsuarioIdEditar.value = u.id;
        if (inputUsuarioNombre) inputUsuarioNombre.value = u.nombre || "";
        if (inputUsuarioCorreo) inputUsuarioCorreo.value = u.email || "";
        if (inputUsuarioRol) inputUsuarioRol.value = u.rol || "Administrador";
        if (inputUsuarioPassword) {
            inputUsuarioPassword.value = "";
            inputUsuarioPassword.placeholder = "Dejar en blanco para no cambiarla";
        }

        if (btnGuardarUsuario) btnGuardarUsuario.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Guardar cambios';
        if (btnCancelarEdicionUsuario) btnCancelarEdicionUsuario.style.display = "inline-flex";

        limpiarMensajeUsuarios();
        if (formularioUsuario) formularioUsuario.scrollIntoView({ behavior: "smooth", block: "start" });
    }

    function limpiarFormularioUsuario() {
        if (inputUsuarioIdEditar) inputUsuarioIdEditar.value = "";
        if (inputUsuarioNombre) inputUsuarioNombre.value = "";
        if (inputUsuarioCorreo) inputUsuarioCorreo.value = "";
        if (inputUsuarioRol) inputUsuarioRol.value = "Administrador";
        if (inputUsuarioPassword) {
            inputUsuarioPassword.value = "";
            inputUsuarioPassword.placeholder = "Mínimo 4 caracteres";
        }

        if (btnGuardarUsuario) btnGuardarUsuario.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Guardar usuario';
        if (btnCancelarEdicionUsuario) btnCancelarEdicionUsuario.style.display = "none";

        limpiarMensajeUsuarios();
    }

    if (btnCancelarEdicionUsuario) {
        btnCancelarEdicionUsuario.addEventListener("click", limpiarFormularioUsuario);
    }

    if (btnGuardarUsuario) {
        btnGuardarUsuario.addEventListener("click", () => {
            const idEditar = inputUsuarioIdEditar ? inputUsuarioIdEditar.value.trim() : "";
            const nombre = inputUsuarioNombre ? inputUsuarioNombre.value.trim() : "";
            const correo = inputUsuarioCorreo ? inputUsuarioCorreo.value.trim() : "";
            const rol = inputUsuarioRol ? inputUsuarioRol.value : "Administrador";
            const password = inputUsuarioPassword ? inputUsuarioPassword.value : "";

            if (!nombre || !correo) {
                mostrarMensajeUsuarios("Por favor completa nombre y correo.");
                return;
            }

            if (!idEditar && !password) {
                mostrarMensajeUsuarios("Escribe una contraseña para el usuario nuevo.");
                return;
            }

            const datos = new URLSearchParams();
            datos.append("nombre", nombre);
            datos.append("correo", correo);
            datos.append("rol", rol);
            datos.append("password", password);

            const url = idEditar ? "php/usuarios_editar.php" : "php/usuarios_crear.php";
            if (idEditar) datos.append("id", idEditar);

            fetch(url, { method: "POST", body: datos })
                .then(respuesta => respuesta.json())
                .then(data => {
                    if (!data.exito) {
                        mostrarMensajeUsuarios(data.mensaje || "No se pudo guardar el usuario.");
                        return;
                    }

                    mostrarMensajeUsuarios(data.mensaje || "¡Guardado con éxito!", "#4ee28b");
                    limpiarFormularioUsuario();
                    cargarUsuarios();
                })
                .catch(error => {
                    console.error("Error al guardar usuario:", error);
                    mostrarMensajeUsuarios("Error de conexión con el servidor.");
                });
        });
    }

    function eliminarUsuario(id, nombre) {
        const confirmado = confirm(`¿Estás seguro de eliminar al usuario "${nombre}"?`);
        if (!confirmado) return;

        const datos = new URLSearchParams();
        datos.append("id", id);

        fetch("php/usuarios_eliminar.php", { method: "POST", body: datos })
            .then(respuesta => respuesta.json())
            .then(data => {
                if (!data.exito) {
                    mostrarMensajeUsuarios(data.mensaje || "No se pudo eliminar el usuario.");
                    return;
                }
                cargarUsuarios();
            })
            .catch(error => {
                console.error("Error al eliminar usuario:", error);
                mostrarMensajeUsuarios("Error de conexión al eliminar.");
            });
    }


    /*═══════════════════════════════════════════════════════════════════════
      4. REPORTES (datos consultados desde php/reportes_resumen.php)
    ═══════════════════════════════════════════════════════════════════════*/
    const formatoMoneda = new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 });

    function asignarTextoReporte(id, valor) {
        const elemento = document.getElementById(id);
        if (elemento) elemento.textContent = valor;
    }

    function obtenerPeriodosRecientes() {
        const fecha = new Date();
        fecha.setDate(1);
        const periodos = [];
        for (let i = 5; i >= 0; i--) {
            const mes = new Date(fecha.getFullYear(), fecha.getMonth() - i, 1);
            periodos.push(`${mes.getFullYear()}-${String(mes.getMonth() + 1).padStart(2, "0")}`);
        }
        return periodos;
    }

    function dibujarGraficaActividad(datos) {
        const contenedor = document.getElementById("graficaActividadMensual");
        if (!contenedor) return;
        const porPeriodo = Object.fromEntries(datos.map(item => [item.periodo, item.reservas]));
        const meses = obtenerPeriodosRecientes();
        const valores = meses.map(periodo => Number(porPeriodo[periodo] || 0));
        const maximo = Math.max(...valores, 1);
        contenedor.innerHTML = "";
        valores.forEach((valor, indice) => {
            const [anio, mes] = meses[indice].split("-");
            const etiqueta = new Intl.DateTimeFormat("es-CO", { month: "short" }).format(new Date(Number(anio), Number(mes) - 1, 1)).replace(".", "");
            const columna = document.createElement("div");
            columna.className = "barra-mensual";
            columna.innerHTML = `<strong>${valor}</strong><div class="barra-mensual-relleno" style="height: ${Math.max((valor / maximo) * 100, valor ? 8 : 2)}%"></div><span>${etiqueta}</span>`;
            contenedor.appendChild(columna);
        });
    }

    function cargarReportes() {
        fetch("php/reportes_resumen.php")
            .then(respuesta => respuesta.json())
            .then(data => {
                if (!data.exito) throw new Error(data.mensaje || "No se pudieron cargar los reportes.");
                const r = data.resumen;
                asignarTextoReporte("reporteTotalVehiculos", r.totalVehiculos);
                asignarTextoReporte("reporteTotalReservas", r.reservasMes);
                asignarTextoReporte("reporteTotalClientes", r.totalClientes);
                asignarTextoReporte("reporteTotalIngresos", formatoMoneda.format(r.ingresosMes));
                asignarTextoReporte("repVehiculosDisponibles", r.vehiculosDisponibles);
                asignarTextoReporte("repVehiculosAlquilados", r.vehiculosAlquilados);
                asignarTextoReporte("repVehiculosMantenimiento", r.vehiculosMantenimiento);
                asignarTextoReporte("repVehiculosEnReserva", r.vehiculosEnReserva);
                asignarTextoReporte("repReservasPendientes", r.reservasPendientes);
                asignarTextoReporte("repPagosPendientes", r.pagosPendientes);
                dibujarGraficaActividad(data.actividadMensual || []);
            })
            .catch(error => {
                console.error("Error al cargar reportes:", error);
                const grafica = document.getElementById("graficaActividadMensual");
                if (grafica) grafica.textContent = "No fue posible cargar la actividad mensual.";
            });
    }
    window.cargarReportesGlobal = cargarReportes;

    /*═══════════════════════════════════════════════════════════════════════
      5. LOGIN (CONEXIÓN CON php/login.php)
    ═══════════════════════════════════════════════════════════════════════*/

    if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
            e.preventDefault();

            const usuario = inputUsuario.value.trim();
            const password = inputPassword.value;

            limpiarErrorLogin();

            const datos = new URLSearchParams();
            datos.append("usuario", usuario);
            datos.append("password", password);

            fetch("php/login.php", { method: "POST", body: datos })
                .then(respuesta => respuesta.json())
                .then(data => {
                    if (!data.exito) {
                        mostrarErrorLogin(data.mensaje || "Credenciales incorrectas.");
                        inputPassword.value = "";
                        return;
                    }

                    // Ocultar login y mostrar dashboard administrativo
                    if (login) login.style.display = "none";
                    if (dashboard) dashboard.style.display = "flex";

                    // ==========================================
                    // ¡LLAMA A LA SINCRONIZACIÓN AQUÍ MISMO!
                    // ==========================================
                    if (typeof window.sincronizarDatosSesion === "function") {
                        window.sincronizarDatosSesion();
                    }

                    // Ir a la sección por defecto (Inicio)
                    window.cambiarSeccion("inicio");
                    if (tituloPagina) tituloPagina.textContent = "Inicio";

                    loginForm.reset();
                })
                .catch(error => {
                    console.error("Error en el login:", error);
                    mostrarErrorLogin("Error de conexión con el servidor.");
                });
        });
    }


    /*═══════════════════════════════════════════════════════════════════════
      5. CERRAR SESIÓN
    ═══════════════════════════════════════════════════════════════════════*/

    function cerrarSesion() {
        mostrarSoloLogin();
        limpiarErrorLogin();
        if (loginForm) loginForm.reset();
        if (inputUsuario) inputUsuario.focus();

        fetch("php/logout.php", { method: "POST" }).catch(error => {
            console.error("Error al cerrar sesión en servidor:", error);
        });
    }

    if (btnCerrarAdmin) {
        btnCerrarAdmin.addEventListener("click", cerrarSesion);
    }


    /*═══════════════════════════════════════════════════════════════════════
      6. INICIALIZACIÓN DE EVENTOS DEL MENÚ LATERAL
    ═══════════════════════════════════════════════════════════════════════*/

    const botonesMenu = document.querySelectorAll(".sidebar-menu button");
    botonesMenu.forEach(boton => {
        boton.addEventListener("click", () => {
            const destino = boton.getAttribute("data-contenedor");
            if (destino) {
                window.cambiarSeccion(destino);
            }
        });
    });

    // Iniciar mostrando solo el login
    mostrarSoloLogin();


    /*═══════════════════════════════════════════════════════════════════════
      7. REGISTRO DE VEHÍCULO (AJAX SIN RECARGAR)
    ═══════════════════════════════════════════════════════════════════════*/

    const formVehiculo = document.getElementById("formVehiculo");
    if (formVehiculo) {
        formVehiculo.addEventListener("submit", async function(e) {
            e.preventDefault(); // Evita que la página se recargue y te redirija

            const formData = new FormData(this);

            try {
                const respuesta = await fetch("php/vehiculos_crear.php", {
                    method: "POST",
                    body: formData
                });
                const resultado = await respuesta.json();

                if (resultado.exito) {
                    this.reset(); // Limpia el formulario si se guardó bien
                    if (typeof toggleFormularioVehiculo === "function") {
                        toggleFormularioVehiculo(); // Cierra el modal automáticamente
                    }
                    refrescarTablaVehiculos();
                } else {
                    alert(resultado.mensaje); // Muestra el mensaje solo si hubo un error específico devuelto por PHP
                }
            } catch (error) {
                console.error("Error al procesar la solicitud:", error);
            }
        });
    }

});

function toggleFormularioCliente() {
    const modal = document.getElementById('modalClienteOverlay');

    if (modal.style.display === 'flex') {
        modal.style.display = 'none';
    } else {
        modal.style.display = 'flex';
    }
}

function toggleFormularioVehiculo() {
    const modal = document.getElementById('modalVehiculoOverlay');

    if (modal.style.display === 'flex') {
        modal.style.display = 'none';
    } else {
        modal.style.display = 'flex';
    }
}

function toggleFormularioReserva() {
    const modal = document.getElementById('modalReservaOverlay');

    if (modal.style.display === 'flex') {
        modal.style.display = 'none';
    } else {
        modal.style.display = 'flex';
    }
}

// Función independiente para actualizar el listado cuando se actualice la base de datos
function refrescarTablaVehiculos() {
    if (typeof cargarVehiculos === "function") {
        cargarVehiculos();
    }
}

/*═══════════════════════════════════════════════════════════════════════
      GESTIÓN Y LISTADO DE VEHÍCULOS
═══════════════════════════════════════════════════════════════════════*/

function cargarVehiculos() {
    const tablaVehiculos = document.getElementById("tablaVehiculos");
    if (!tablaVehiculos) return;

    tablaVehiculos.innerHTML = '<tr><td colspan="8" style="text-align:center;">Cargando vehículos...</td></tr>';

    fetch("php/vehiculos_listar.php")
        .then(respuesta => respuesta.json())
        .then(data => {
            if (!data.exito) {
                tablaVehiculos.innerHTML = `<tr><td colspan="8" style="text-align:center;">${data.mensaje || "No se pudo cargar la lista."}</td></tr>`;
                return;
            }

            if (!data.vehiculos || data.vehiculos.length === 0) {
                tablaVehiculos.innerHTML = '<tr><td colspan="8" style="text-align:center;">No hay vehículos registrados.</td></tr>';
                return;
            }

            tablaVehiculos.innerHTML = "";

            data.vehiculos.forEach(v => {
                const fila = document.createElement("tr");

                const precioFormateado = "$" + Number(v.precio_dia).toLocaleString('es-CO');
                const claseEstado = (v.estado && v.estado.toLowerCase() === "disponible") ? "disponible" : "alquilado";

                fila.innerHTML = `
                    <td>${v.placa || "N/A"}</td>
                    <td>${v.marca || ""}</td>
                    <td>${v.modelo || ""}</td>
                    <td>${v.anio || ""}</td>
                    <td>${v.tipo || ""}</td>
                    <td>
                        <span class="estado ${claseEstado}">${v.estado || "Disponible"}</span>
                    </td>
                    <td>${precioFormateado}</td>
                    <td>
                        <button class="btn-editar" title="Editar"><i class="fa-solid fa-pen"></i></button>
                        <button class="btn-eliminar" title="Eliminar"><i class="fa-solid fa-trash"></i></button>
                    </td>
                `;

                tablaVehiculos.appendChild(fila);
            });
        })
        .catch(error => {
            console.error("Error al listar vehículos:", error);
            tablaVehiculos.innerHTML = '<tr><td colspan="8" style="text-align:center;">Error de conexión al cargar la tabla.</td></tr>';
        });
}

// Cargar al iniciar la página
document.addEventListener("DOMContentLoaded", () => {
    cargarVehiculos();
});

/*═══════════════════════════════════════════════════════════════════════
  INICIO: tarjetas resumen conectadas a php/inicio_resumen.php
═══════════════════════════════════════════════════════════════════════*/

// Rellena las tarjetas de la pestaña Inicio con los datos ya calculados.
function pintarTarjetasInicio(resumen) {
    const elVehiculos = document.getElementById("inicioTotalVehiculos");
    const elReservas = document.getElementById("inicioReservasActivas");
    const elClientes = document.getElementById("inicioTotalClientes");
    const elIngresos = document.getElementById("inicioIngresosMes");

    if (elVehiculos) elVehiculos.textContent = resumen.totalVehiculos;
    if (elReservas) elReservas.textContent = resumen.reservasActivasSemana;
    if (elClientes) elClientes.textContent = resumen.totalClientes;
    if (elIngresos) elIngresos.textContent = monedaZynco(resumen.ingresosMes);
}

// Pide el resumen al backend y lo pinta. Se llama al entrar a "Inicio".
function cargarInicioGlobal() {
    fetch("php/inicio_resumen.php")
        .then(respuesta => respuesta.json())
        .then(data => {
            if (!data.exito) throw new Error(data.mensaje);
            pintarTarjetasInicio(data.resumen);
        })
        .catch(error => {
            console.error("Error al cargar el resumen de inicio:", error);
        });
}
window.cargarInicioGlobal = cargarInicioGlobal;

/*═══════════════════════════════════════════════════════════════════════
  PAGOS Y RESERVAS: datos reales, registro y comprobante no editable
  (Módulo unificado — antes vivía duplicado en pagos.js)
═══════════════════════════════════════════════════════════════════════*/
function textoSeguro(valor) {
    return String(valor ?? "").replace(/[&<>'"]/g, caracter => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
    })[caracter]);
}

function monedaZynco(valor) {
    return new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(Number(valor || 0));
}

function fechaZynco(valor, incluirHora = false) {
    if (!valor) return "No disponible";
    const fecha = new Date(String(valor).replace(" ", "T"));
    return new Intl.DateTimeFormat("es-CO", {
        dateStyle: "medium", ...(incluirHora ? { timeStyle: "medium" } : {})
    }).format(fecha);
}

function claseEstadoZynco(estado) {
    const estadoNormalizado = String(estado || "").toLowerCase();
    if (estadoNormalizado === "pagada" || estadoNormalizado === "aprobada" || estadoNormalizado === "disponible") return "disponible";
    if (estadoNormalizado === "pendiente") return "mantenimiento";
    return "alquilado";
}

function cargarReservas() {
    const tabla = document.getElementById("tablaReservas");
    if (!tabla) return;
    tabla.innerHTML = '<tr><td colspan="8" style="text-align:center;">Cargando reservas...</td></tr>';
    fetch("php/reservas_listar.php")
        .then(respuesta => respuesta.json())
        .then(data => {
            if (!data.exito) throw new Error(data.mensaje);
            if (!data.reservas.length) {
                tabla.innerHTML = '<tr><td colspan="8" style="text-align:center;">No hay reservas registradas.</td></tr>';
                return;
            }
            window.reservasDisponiblesPago = data.reservas;
            tabla.innerHTML = "";
            data.reservas.forEach(reserva => {
                const fila = document.createElement("tr");
                const puedeRegistrar = !reserva.tiene_pago && String(reserva.estado).toLowerCase() === "pendiente";
                fila.innerHTML = `<td>R${reserva.id}</td><td>${textoSeguro(reserva.cliente_nombre)}</td><td>${textoSeguro(reserva.marca)} ${textoSeguro(reserva.modelo)}</td><td>${fechaZynco(reserva.fecha_inicio)}</td><td>${fechaZynco(reserva.fecha_fin)}</td><td>${monedaZynco(reserva.costo_total)}</td><td><span class="estado ${claseEstadoZynco(reserva.estado)}">${textoSeguro(reserva.estado)}</span></td><td></td>`;
                const acciones = fila.lastElementChild;
                if (puedeRegistrar) {
                    const boton = document.createElement("button");
                    boton.className = "btn-verde";
                    boton.title = "Registrar pago";
                    boton.setAttribute("aria-label", `Registrar pago de reserva R${reserva.id}`);
                    boton.innerHTML = '<i class="fa-solid fa-file-invoice-dollar"></i>';
                    boton.addEventListener("click", () => abrirPagoReserva(reserva));
                    acciones.appendChild(boton);
                } else {
                    acciones.textContent = reserva.tiene_pago ? "Pago registrado" : "Sin acciones";
                }
                tabla.appendChild(fila);
            });
        })
        .catch(error => {
            console.error("Error al listar reservas:", error);
            tabla.innerHTML = '<tr><td colspan="8" style="text-align:center;">No se pudieron cargar las reservas.</td></tr>';
        });
}

function abrirPagoReserva(reserva) {
    document.getElementById("pagoId").value = "";
    document.getElementById("clientePago").value = `${reserva.cliente_nombre} (${reserva.cliente_documento})`;
    document.getElementById("selectReservaPago").value = reserva.id;
    document.getElementById("valorPago").value = reserva.costo_total;
    document.getElementById("metodoPago").value = "";
    document.getElementById("modalPagoOverlay").style.display = "flex";
}

function abrirPagoExistente(pago) {
    document.getElementById("pagoId").value = pago.id;
    document.getElementById("clientePago").value = `${pago.cliente_nombre} (${pago.cliente_documento})`;
    document.getElementById("selectReservaPago").value = pago.reserva_id;
    document.getElementById("valorPago").value = pago.monto;
    document.getElementById("metodoPago").value = pago.metodo_pago;
    document.getElementById("modalPagoOverlay").style.display = "flex";
}

function abrirPagoDisponible() {
    const pendientes = (window.reservasDisponiblesPago || []).filter(reserva => !reserva.tiene_pago && String(reserva.estado).toLowerCase() === "pendiente");
    if (pendientes.length === 1) {
        abrirPagoReserva(pendientes[0]);
        return;
    }
    if (pendientes.length === 0) {
        alert("No hay reservas pendientes de pago.");
        return;
    }
    window.cambiarSeccion("reservas");
    alert("Selecciona el botón de pago de la reserva que deseas registrar.");
}

function cerrarFormularioPago() {
    const modal = document.getElementById("modalPagoOverlay");
    if (modal) modal.style.display = "none";
    const formulario = document.getElementById("formPago");
    if (formulario) formulario.reset();
}

function cargarPagos() {
    const tabla = document.getElementById("tablaPagos");
    if (!tabla) return;
    tabla.innerHTML = '<tr><td colspan="8" style="text-align:center;">Cargando pagos...</td></tr>';
    fetch("php/pagos_listar.php")
        .then(respuesta => respuesta.json())
        .then(data => {
            if (!data.exito) throw new Error(data.mensaje);
            if (!data.pagos.length) {
                tabla.innerHTML = '<tr><td colspan="8" style="text-align:center;">No hay pagos registrados.</td></tr>';
                return;
            }
            tabla.innerHTML = "";
            data.pagos.forEach(pago => {
                const fila = document.createElement("tr");
                fila.innerHTML = `<td>P${pago.id}</td><td>${textoSeguro(pago.cliente_nombre)}</td><td>R${pago.reserva_id}</td><td>${fechaZynco(pago.fecha_pago, true)}</td><td>${textoSeguro(pago.metodo_pago)}</td><td>${monedaZynco(pago.monto)}</td><td><span class="estado ${claseEstadoZynco(pago.estado_pago)}">${textoSeguro(pago.estado_pago || "Sin estado")}</span></td><td></td>`;
                const botonRegistrar = document.createElement("button");
                botonRegistrar.className = "btn-verde";
                botonRegistrar.title = "Registrar pago";
                botonRegistrar.setAttribute("aria-label", `Registrar pago P${pago.id}`);
                botonRegistrar.innerHTML = '<i class="fa-solid fa-file-invoice-dollar"></i>';
                botonRegistrar.addEventListener("click", () => abrirPagoExistente(pago));
                fila.lastElementChild.appendChild(botonRegistrar);
                const boton = document.createElement("button");
                boton.className = "btn-ver";
                boton.title = "Ver comprobante";
                boton.setAttribute("aria-label", `Ver comprobante del pago P${pago.id}`);
                boton.innerHTML = '<i class="fa-solid fa-eye"></i>';
                boton.addEventListener("click", () => verComprobante(pago.id));
                fila.lastElementChild.appendChild(boton);
                tabla.appendChild(fila);
            });
        })
        .catch(error => {
            console.error("Error al listar pagos:", error);
            tabla.innerHTML = '<tr><td colspan="8" style="text-align:center;">No se pudieron cargar los pagos.</td></tr>';
        });
}

function verComprobante(pagoId) {
    const modal = document.getElementById("modalComprobanteOverlay");
    const contenido = document.getElementById("contenidoComprobante");
    modal.style.display = "flex";
    contenido.textContent = "Cargando comprobante...";
    fetch(`php/pagos_comprobante.php?id=${encodeURIComponent(pagoId)}`)
        .then(respuesta => respuesta.json())
        .then(data => {
            if (!data.exito) throw new Error(data.mensaje);
            const p = data.pago;
            contenido.innerHTML = `<section><h3>Transacción</h3><p><strong>ID de pago:</strong> P${p.id}</p><p><strong>Fecha y hora:</strong> ${fechaZynco(p.fecha_pago, true)}</p></section><section><h3>Cliente</h3><p><strong>Nombre:</strong> ${textoSeguro(p.cliente_nombre)}</p><p><strong>Documento:</strong> ${textoSeguro(p.cliente_documento)}</p></section><section><h3>Vehículo alquilado</h3><p><strong>Vehículo:</strong> ${textoSeguro(p.marca)} ${textoSeguro(p.modelo)}</p><p><strong>Placa:</strong> ${textoSeguro(p.placa || "No registrada")}</p></section><section><h3>Desglose financiero</h3><p><strong>Monto pagado:</strong> ${monedaZynco(p.monto)}</p><p><strong>Método:</strong> ${textoSeguro(p.metodo_pago)}</p></section><section><h3>Usuario que registró el pago</h3><p><strong>Nombre:</strong> ${textoSeguro(p.usuario_nombre || "No disponible")}</p><p><strong>Cargo / rol:</strong> ${textoSeguro(p.usuario_rol || "No disponible")}</p><p><strong>Correo:</strong> ${textoSeguro(p.usuario_email || "No disponible")}</p></section>`;
        })
        .catch(error => { contenido.textContent = error.message || "No fue posible cargar el comprobante."; });
}

function cerrarComprobante() {
    const modal = document.getElementById("modalComprobanteOverlay");
    if (modal) modal.style.display = "none";
}

window.cargarReservasGlobal = cargarReservas;
window.cargarPagosGlobal = cargarPagos;
window.abrirPagoReserva = abrirPagoReserva;
window.abrirPagoExistente = abrirPagoExistente;
window.abrirPagoDisponible = abrirPagoDisponible;
window.cerrarComprobante = cerrarComprobante;
window.verComprobante = verComprobante;
window.toggleFormularioPago = cerrarFormularioPago;

document.addEventListener("DOMContentLoaded", () => {
    const formularioPago = document.getElementById("formPago");
    if (formularioPago) {
        formularioPago.addEventListener("submit", evento => {
            evento.preventDefault();
            const datos = new FormData(formularioPago);
            fetch("php/pagos_registrar.php", { method: "POST", body: datos })
                .then(respuesta => respuesta.json())
                .then(data => {
                    if (!data.exito) throw new Error(data.mensaje);
                    cerrarFormularioPago();
                    cargarPagos();
                    cargarReservas();
                    if (typeof window.cargarReportesGlobal === "function") window.cargarReportesGlobal();
                })
                .catch(error => alert(error.message || "No se pudo registrar el pago."));
        });
    }

    document.getElementById("buscarPago")?.addEventListener("input", evento => {
        const termino = evento.target.value.toLowerCase();
        document.querySelectorAll("#tablaPagos tr").forEach(fila => { fila.style.display = fila.textContent.toLowerCase().includes(termino) ? "" : "none"; });
    });

    // Carga inicial de reservas y pagos
    cargarReservas();
    cargarPagos();

    // Auto-refresco cada 5s mientras el dashboard esté visible y no haya un modal de pago abierto
    setInterval(() => {
        const dashboard = document.getElementById("dashboard");
        const modalAbierto = document.getElementById("modalPagoOverlay")?.style.display === "flex";

        if (dashboard && dashboard.style.display !== "none" && !modalAbierto) {
            cargarReservas();
            cargarPagos();
        }
    }, 5000);
});

/*═══════════════════════════════════════════════════════════════════════
  GESTIÓN Y LISTADO DE CLIENTES (CORRECCIÓN Y CONEXIÓN)
═══════════════════════════════════════════════════════════════════════*/

function cargarClientes() {
    const tablaClientes = document.getElementById("tablaClientes");
    if (!tablaClientes) return;

    tablaClientes.innerHTML = '<tr><td colspan="8" style="text-align:center;">Cargando clientes...</td></tr>';

    fetch("php/clientes_listar.php")
        .then(respuesta => respuesta.json())
        .then(data => {
            if (!data.exito) {
                tablaClientes.innerHTML = `<tr><td colspan="8" style="text-align:center;">${data.mensaje || "No se pudo cargar la lista."}</td></tr>`;
                return;
            }

            if (!data.clientes || data.clientes.length === 0) {
                tablaClientes.innerHTML = '<tr><td colspan="8" style="text-align:center;">No hay clientes registrados.</td></tr>';
                return;
            }

            tablaClientes.innerHTML = "";

            data.clientes.forEach(c => {
                const fila = document.createElement("tr");
                const estadoTexto = c.estado || "";
                const estadoClase = estadoTexto.toLowerCase() === "activo" ? "disponible" : "alquilado";

                fila.innerHTML = `
                    <td>${textoSeguro(c.id)}</td>
                    <td>${textoSeguro(c.nombre)}</td>
                    <td>${textoSeguro(c.email)}</td>
                    <td>${textoSeguro(c.telefono)}</td>
                    <td>${c.fecha_registro ? fechaZynco(c.fecha_registro) : ""}</td>
                    <td>${textoSeguro(c.direccion)}</td>
                    <td>${estadoTexto ? `<span class="estado ${estadoClase}">${textoSeguro(estadoTexto)}</span>` : ""}</td>
                    <td>
                        <button class="btn-editar" title="Editar"><i class="fa-solid fa-pen"></i></button>
                        <button class="btn-eliminar" title="Desactivar/Eliminar"><i class="fa-solid fa-ban"></i></button>
                    </td>
                `;

                // Evento para Editar
                fila.querySelector(".btn-editar").addEventListener("click", () => {
                    if (typeof toggleFormularioCliente === "function") toggleFormularioCliente();
                    // Si tienes los inputs del modal de cliente, los rellenamos aquí:
                    const inputId = document.getElementById("clienteId");
                    const inputNombre = document.getElementById("clienteNombre");
                    const inputTelefono = document.getElementById("clienteTelefono");
                    const inputEmail = document.getElementById("clienteEmail");
                    const inputDireccion = document.getElementById("clienteDireccion");

                    if (inputId) inputId.value = c.id;
                    if (inputNombre) inputNombre.value = c.nombre;
                    if (inputTelefono) inputTelefono.value = c.telefono || "";
                    if (inputEmail) inputEmail.value = c.email || "";
                    if (inputDireccion) inputDireccion.value = c.direccion || "";
                });

                // Evento para Desactivar / Eliminar
                fila.querySelector(".btn-eliminar").addEventListener("click", () => {
                    if (!confirm(`¿Estás seguro de desactivar/eliminar al cliente ${c.nombre}?`)) return;

                    const datos = new URLSearchParams();
                    datos.append("id", c.id);

                    fetch("php/cliente_desactivar.php", { method: "POST", body: datos })
                        .then(res => res.json())
                        .then(resData => {
                            if (!resData.exito) {
                                alert(resData.mensaje || "No se pudo procesar la solicitud.");
                                return;
                            }
                            cargarClientes();
                        })
                        .catch(err => console.error("Error al desactivar cliente:", err));
                });

                tablaClientes.appendChild(fila);
            });
        })
        .catch(error => {
            console.error("Error al listar clientes:", error);
            tablaClientes.innerHTML = '<tr><td colspan="8" style="text-align:center;">Error de conexión al cargar la tabla de clientes.</td></tr>';
        });
}

// Vincular el formulario de guardar cliente si existe en el HTML
document.addEventListener("DOMContentLoaded", () => {
    const formCliente = document.getElementById("formCliente") || document.querySelector(".formulario-cliente");
    if (formCliente) {
        formCliente.addEventListener("submit", e => {
            e.preventDefault();
            const datos = new FormData(formCliente);

            fetch("php/clientes_guardar.php", { method: "POST", body: datos })
                .then(res => res.json())
                .then(data => {
                    if (!data.exito) {
                        alert(data.mensaje || "Error al guardar el cliente.");
                        return;
                    }
                    alert(data.mensaje);
                    formCliente.reset();
                    if (typeof toggleFormularioCliente === "function") toggleFormularioCliente();
                    cargarClientes();
                })
                .catch(err => console.error("Error al guardar cliente:", err));
        });
    }

    // Cargar clientes al iniciar si ya está activa la vista
    cargarClientes();
});

// Registrar la función globalmente para que el sistema la llame cuando cambies de sección
window.cargarClientesGlobal = cargarClientes;