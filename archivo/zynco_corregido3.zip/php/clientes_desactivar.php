<?php
header("Content-Type: application/json; charset=utf-8");
session_start();
require "conectar.php";
require "sesion.php";

// La tabla clientes actual no posee una columna de estado. No se borra información
// para simular una desactivación; el endpoint comunica el requisito de esquema.
http_response_code(409);
echo json_encode([
    'exito' => false,
    'mensaje' => 'La base de datos no tiene un campo estado en clientes. Agrega un estado para poder desactivar sin eliminar información.',
]);
$mysqli->close();
